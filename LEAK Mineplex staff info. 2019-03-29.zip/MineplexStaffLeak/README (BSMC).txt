Leaked by BadLeakGuy! 

https://blackspigot.com/members/badleakguy.124893/

(Google Drive)https://docs.google.com/document/d/1B4GCe4mLMIol9xoZSZa6zKtGGgUI8UTnxRprHWl5u7Q/edit
